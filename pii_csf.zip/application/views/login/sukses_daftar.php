<!DOCTYPE html>
<html lang="en">
<head>
    <title>Register</title>
    <meta charset="UTF-8">
    <base href="<?php echo base_url() ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">

<!-- bootstrap-3.3.7 -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>


</head>
<body>

<div class="container">
	<div class="row">
		<center>
		<h4>TERIMAKASIH ATAS PENDAFTARAN ANDA</h4> 
		<img src="<?php echo base_url('assets/register/images/svgator-fig5.gif'); ?>" width="20%" /><br/><br/>
		Untuk pertama kali login silahkan login dari link yang telah di berikan melalui <i>email</i> <a href="<?php echo site_url('Login') ?>"> Kembali halaman Login </a>
		</center>
	</div>

</div>

</body>
</html>